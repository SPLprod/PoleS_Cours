# TP#5 Miaou 
> Pour ce TP n'utilisez que la méthode flex pour positionner vos éléments.

TP#1 Miaou 
 
Créer un repository 

Créez un dossier CSS dans lequel vous rangerez votre feuille de style 

Créez votre index.html à la racine du projet : 

Le doctype doit être correctement rempli 

Les balises head, body doivent apparaître 

Les balises header et footer doivent apparaître si nécessaire 

Intégrez tous les éléments HTML nécessaires (font, links, images…) 

Créez le fichier style.css dans CSS  

Travaillez à la fois sur la structure et sur la forme afin d’obtenir un rendu aussi proche que possible de la maquette 


## Colors
blanc: #ffffff
indigo: #29347B

## Font
Shadows Into Light

## Texts
- Les missions du chat
- Chat qui chasse
- Chat dort
- Chat lèche
- Chat chante
- Chat caché
- Chat a F-A-I-M
- Chat grignote
- Trop mangé
- Chat ninja

### Gestion du responsif
- Jaugez comment mettre en place vos éléments pour la partie responsive 😉

# PS : Envoyez moi les liens de vos repositories en privé sur teams ! Si vous avez fait un repo en privé n'oubliez pas de me donnez l'accès